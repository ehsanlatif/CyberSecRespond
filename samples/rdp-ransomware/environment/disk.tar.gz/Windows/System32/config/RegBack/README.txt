Registry backup hive location.
